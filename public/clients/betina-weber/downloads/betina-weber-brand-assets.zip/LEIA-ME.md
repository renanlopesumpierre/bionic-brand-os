# Logotipos — Betina Weber

Gerado pelo Bionic Brand OS em 26/04/2026.

Este pacote contém os arquivos oficiais do logotipo de Betina Weber, em vetor (SVG), bitmap de alta resolução (PNG @4x) e símbolo animado (GIF), quando aplicável.

---

## O que tem aqui

```
betina-weber-brand-assets/
├── svg/        ← vetor, escalável sem perda. Use sempre que possível.
├── png/        ← rasterizado @4x (ideal pra PowerPoint, Word, redes sociais)
├── animado/    ← GIF (uso digital, intros, loaders)
├── LEIA-ME.pdf  ← este documento
└── LEIA-ME.md
```

**Variantes incluídas:** 4 versãos em SVG/PNG + 1 animação GIF.

---

## Quando usar cada formato

| Formato | Quando usar | Quando NÃO usar |
|---|---|---|
| **SVG** | Web, sistemas internos, design (Figma, Adobe), impressão vetorial | Microsoft Office (suporte limitado) |
| **PNG @4x** | Slides, documentos Word, redes sociais, e-mails | Impressão grande (use SVG) |
| **GIF animado** | Intro de vídeo, loader, post de redes sociais | Materiais institucionais (use estático) |

---

## Variantes — quando usar qual

A maioria das marcas tem 2 variantes principais:

- **Logo positivo (preto)** — usar sobre fundos claros (branco, canvas, qualquer superfície clara)
- **Logo negativo (branco)** — usar sobre fundos escuros (preto, escuro institucional, fotos com pouca luz)

Ícone (versão reduzida) — usar quando o wordmark completo perde legibilidade: favicon, app icon, avatar de perfil, badge.

---

## Regras universais (independem da marca)

- **Espaço de proteção:** mantenha ao redor do logo um espaço livre equivalente à altura da letra-base. Nada pode invadir essa área.
- **Tamanho mínimo:**
  - Wordmark: 80px de largura mínima na tela; 25mm na impressão.
  - Ícone: 24px na tela; 10mm na impressão.
- **Não distorça:** nunca esticar, achatar ou rotacionar o logo. Use o arquivo nativo no tamanho certo.
- **Não recolore:** use só as variantes oficiais (positivo/negativo). Não aplicar gradientes, sombras, contornos, brilhos.
- **Não componha:** o logo é um sistema fechado. Não adicione tagline embaixo, não combine com outro logo sem espaço de proteção dobrado.

---

## Bandeiras vermelhas — refuse se vir

- Logo esticado horizontal/vertical
- Logo com sombra, glow, gradiente ou contorno
- Logo aplicado direto sobre foto sem garantir contraste
- Logo em cor não oficial
- Logo invadido por elemento gráfico
- Versão antiga junto com nova no mesmo material

---

## Pacotes relacionados

- **`betina-weber-brand-colors.zip`** — paleta oficial em 16 formatos (web, design, gráfica, mobile)
- **`betina-weber-brand-fonts.zip`** — fontes da marca
- **`betina-weber-brand-system.zip`** — sistema de marca completo (estratégia + visual + verbal + governança)

---

_Gerado pelo Bionic Brand OS._
