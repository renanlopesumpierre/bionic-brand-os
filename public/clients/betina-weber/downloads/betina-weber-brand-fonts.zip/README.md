# Betina Weber — Tipografia da marca

Versão: 1.2.0

Cada família vem em duas versões:
- `ttf/` — um arquivo por peso, com todos os glyphs. Use no Figma, Adobe, ou instale no SO.
- `woff2/` — versões subsetted otimizadas para web. Carregue via `fontface.css`.

## Spectral
- Papel: Display · serif
- Pesos disponíveis: 200, 300, 400, 500, 600, 700, 800
- Pesos do brand system: 200, 300
- Fonte: Google Fonts — https://fonts.google.com/specimen/Spectral
- Stack CSS: `Spectral, 'Times New Roman', Georgia, serif`
- Uso: Toda hierarquia de heading. Letter-spacing negativo agressivo em tamanhos ≥ 36px. Brand usa 200 e 300; demais pesos disponíveis para cenários auxiliares.

## TASA Orbiter
- Papel: Body · sans
- Pesos disponíveis: 400, 500, 600, 700, 800
- Pesos do brand system: 400, 500
- Fonte: Google Fonts — https://fonts.google.com/specimen/TASA+Orbiter
- Stack CSS: `'TASA Orbiter', Inter, ui-sans-serif, system-ui, sans-serif`
- Uso: Body, UI, navegação, labels. Humanismo executivo sem competir com a serif. Brand usa 400 e 500; demais pesos disponíveis para cenários auxiliares.

---

Arquivos servidos diretamente do Google Fonts. Confira a licença de cada família no site de origem antes de redistribuir.