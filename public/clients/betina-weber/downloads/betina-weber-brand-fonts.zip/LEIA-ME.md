# Tipografia — Betina Weber

Versão 1.2.0 · gerado pelo Bionic Brand OS em 26/04/2026.

Este pacote contém as fontes oficiais da marca **Betina Weber** em dois formatos: `.ttf` (instalável no SO, abre em qualquer ferramenta) e `.woff2` (otimizado pra web).

---

## Estrutura

Cada família tem sua própria pasta com:

- **`ttf/`** — um arquivo por peso, com todos os glyphs. Use no Figma, Adobe, ou **instale no sistema operacional** (Mac: clique 2x no arquivo → Instalar; Windows: clique direito → Instalar).
- **`woff2/`** — versões subsetted otimizadas pra web. Carregue via `fontface.css`.
- **`fontface.css`** — declarações `@font-face` prontas pra colar no projeto web.

## Como usar

### No Figma / Adobe / Sketch
1. Instale os `.ttf` no SO (Mac: Font Book; Windows: Painel de Controle → Fontes).
2. Reinicie a ferramenta de design.
3. As famílias aparecem no seletor de fontes.

### No Microsoft Office (Word, PowerPoint)
1. Mesma instalação no SO.
2. **Atenção:** ao compartilhar o arquivo, embuta a fonte (Word: Arquivo → Opções → Salvar → Incorporar fontes) ou o destinatário verá fallback genérico.

### No web (HTML/CSS)
1. Copie a pasta `woff2/` da família que quer pro projeto.
2. Cole o conteúdo do `fontface.css` no seu CSS principal (ou importe o arquivo).
3. Use no CSS: `font-family: "NomeDaFonte", -apple-system, sans-serif;`

---

## Famílias incluídas

## Spectral
- Papel: Display · serif
- Pesos disponíveis: 200, 300, 400, 500, 600, 700, 800
- Pesos do brand system: 200, 300
- Fonte: Google Fonts — https://fonts.google.com/specimen/Spectral
- Stack CSS: `Spectral, 'Times New Roman', Georgia, serif`
- Uso: Toda hierarquia de heading. Letter-spacing negativo agressivo em tamanhos ≥ 36px. Brand usa 200 e 300; demais pesos disponíveis para cenários auxiliares.

## TASA Orbiter
- Papel: Body · sans
- Pesos disponíveis: 400, 500, 600, 700, 800
- Pesos do brand system: 400, 500
- Fonte: Google Fonts — https://fonts.google.com/specimen/TASA+Orbiter
- Stack CSS: `'TASA Orbiter', Inter, ui-sans-serif, system-ui, sans-serif`
- Uso: Body, UI, navegação, labels. Humanismo executivo sem competir com a serif. Brand usa 400 e 500; demais pesos disponíveis para cenários auxiliares.

---

## Licença

Arquivos servidos diretamente do Google Fonts (ou outra fonte indicada acima). Confira a licença de cada família no site de origem antes de redistribuir comercialmente. A maioria é Open Font License (OFL), que permite uso comercial e embed em produtos.

---

## Pacotes relacionados

- **`betina-weber-brand-colors.zip`** — paleta oficial em 16 formatos
- **`betina-weber-brand-assets.zip`** — logotipos (SVG, PNG, GIF)
- **`betina-weber-brand-system.zip`** — sistema de marca completo

---

_Gerado pelo Bionic Brand OS._