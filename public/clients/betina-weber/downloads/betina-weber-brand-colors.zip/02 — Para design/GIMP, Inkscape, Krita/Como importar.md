# Como importar no GIMP, Inkscape ou Krita

O arquivo `Betina Weber.gpl` é o formato de **paleta GIMP** — universal entre essas ferramentas open-source.

## GIMP

1. Abra o GIMP.
2. **Janelas → Diálogos encaixáveis → Paletas**.
3. No painel de paletas, clique no menu hambúrguer → **Importar paleta…** (ou copie o `.gpl` pra `~/.config/GIMP/2.10/palettes/` e reinicie).
4. Aponte pro arquivo `Betina Weber.gpl`.
5. A paleta `Betina Weber` aparece na lista.

## Inkscape

1. Copie `Betina Weber.gpl` pra:
   - **macOS**: `~/Library/Application Support/Inkscape/palettes/`
   - **Windows**: `%APPDATA%\inkscape\palettes\`
   - **Linux**: `~/.config/inkscape/palettes/`
2. Reinicie o Inkscape.
3. Na barra de cores embaixo, clique na seta → escolha `Betina Weber`.

## Krita

1. **Configurações → Recursos → Gerenciar recursos**.
2. **Importar recurso** → escolha o `.gpl`.
3. A paleta aparece em **Janelas → Encaixáveis → Paletas**.

## O que está no arquivo

Apenas as cores sólidas da marca (10 amostras), em RGB. Sem transparências.
