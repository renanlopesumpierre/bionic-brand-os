# Como importar no Figma

O arquivo `betina-weber.tokens.json` segue o **W3C Design Tokens Format Module** — padrão suportado pelo plugin **Tokens Studio for Figma** (gratuito, mantido pela comunidade).

## Passo a passo (5 minutos)

1. Abra o Figma no arquivo onde quer usar a paleta.
2. Menu **Plugins → Procurar mais plugins**.
3. Procure por **Tokens Studio for Figma** (autor: Jan Six).
4. Instale e abra o plugin.
5. Na tela inicial do plugin: **Tools → Load from JSON file**.
6. Selecione o arquivo `betina-weber.tokens.json`.
7. O plugin vai listar todas as cores agrupadas (surface, accent, text, etc.).
8. Clique em **Apply to document**.

Pronto — as cores aparecem como **estilos de cor** do Figma e ficam disponíveis no painel Design.

## Se você não pode/não quer usar o plugin

Você pode criar os estilos manualmente. Abra o arquivo `paleta-canônica (todos os formatos).json` em `05 — Para IAs e automações/` — cada cor tem o HEX pronto. Crie um estilo de cor no Figma pra cada uma seguindo o nome do grupo.

## Atualizando depois

Se a paleta mudar (nova versão), basta repetir o **Tools → Load from JSON file** com a nova versão do `betina-weber.tokens.json`. O plugin substitui os tokens existentes.
