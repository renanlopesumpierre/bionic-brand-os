# Como importar no Adobe (Illustrator, Photoshop, InDesign, After Effects)

O arquivo `Betina Weber.ase` é um **Adobe Swatch Exchange** binário — formato nativo de todas as ferramentas Adobe.

## O caminho mais rápido

1. **Dê duplo-clique** no arquivo `Betina Weber.ase`.
2. O Adobe vai abrir o painel **Swatches** (Janela → Amostras) com o grupo `Betina Weber` já adicionado.
3. Pronto. Use as cores como qualquer outra amostra.

## Se o duplo-clique não funcionar

### Illustrator
1. **Janela → Amostras** (`Window → Swatches`).
2. No menu hambúrguer do painel: **Abrir biblioteca de amostras → Outra biblioteca…**
3. Selecione `Betina Weber.ase`.

### Photoshop
1. **Janela → Amostras** (`Window → Swatches`).
2. Menu hambúrguer → **Importar amostras…**
3. Mude o filtro pra `Swatch Exchange (*.ASE)` e abra o arquivo.

### InDesign
1. **Janela → Cores → Amostras**.
2. Menu do painel → **Carregar amostras…**
3. Selecione o `.ase`.

## O que está no arquivo

Apenas as cores **sólidas** da marca (10 amostras). Cores com transparência (overlays, borders, accent subtle/faint) **não vão** porque o ASE não carrega alpha de forma confiável entre versões. Se precisar dessas, use os SVGs em `../Swatches individuais/`.

## Aviso pra impressão

Os valores no ASE estão em **RGB**. Pra impressão, converta pra CMYK ou (melhor) consulte `03 — Para impressão (gráfica)/Cores em CMYK, LAB e Pantone.json` antes de mandar pro prelo.
