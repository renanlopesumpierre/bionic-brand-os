# Especificação para gráfica — Betina Weber
Documento para o operador de impressão. Cores convertidas de sRGB para CMYK via fórmula naive — **valide sempre com prova impressa antes de tirar do prelo**.
## Recomendações gerais
- Imprimir sobre papel offset 120 g/m² ou superior. Substratos não-revestidos absorvem melhor cores acromáticas e quentes.
- Usar perfil ICC **FOGRA39** ou **GRACoL 2013** para impressão comercial. Coated/Uncoated conforme substrato.
- Acentos cromáticos saturados (ex: Accent Default) podem deslocar matiz em CMYK barato. Considere **spot color Pantone** correspondente em peças críticas (ver sugestão por cor abaixo).
- Para pretos profundos (ex: Surface Inverse, `#1C1917`), evite K100 puro — use **rich black** `C30 M30 Y30 K100` para densidade visual sem virar fosco.
## Cores e equivalências
### Surface Primary `surface.primary`
| Espaço | Valor |
| --- | --- |
| HEX | `#FFFFFF` |
| RGB | `255, 255, 255` |
| CMYK (aprox) | `C 0  M 0  Y 0  K 0` |
| LAB (CIE) | `L 100  a 0  b 0` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `0°, 0%, 100%` |
| Pantone (sugestão) | Branco do papel (não imprimir) |
### Surface Pure `surface.pure`
> Reservado a contextos light, não usar sobre Dark
| Espaço | Valor |
| --- | --- |
| HEX | `#FFFFFF` |
| RGB | `255, 255, 255` |
| CMYK (aprox) | `C 0  M 0  Y 0  K 0` |
| LAB (CIE) | `L 100  a 0  b 0` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `0°, 0%, 100%` |
| Pantone (sugestão) | Branco do papel (não imprimir) |
### Surface Cream `surface.cream`
> v1.1 NOVO — texto/detalhes sobre /Dark
| Espaço | Valor |
| --- | --- |
| HEX | `#F5F0EA` |
| RGB | `245, 240, 234` |
| CMYK (aprox) | `C 0  M 2  Y 4  K 4` |
| LAB (CIE) | `L 95.02  a 0.64  b 3.49` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `33°, 35%, 94%` |
| Pantone (sugestão) | Pantone 9143 C ou Warm Gray 1 C |
### Surface Canvas `surface.canvas`
> Bege pedra, cor-âncora do projeto
| Espaço | Valor |
| --- | --- |
| HEX | `#E5E4DE` |
| RGB | `229, 228, 222` |
| CMYK (aprox) | `C 0  M 0  Y 3  K 10` |
| LAB (CIE) | `L 90.51  a -0.72  b 3.04` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `51°, 12%, 88%` |
| Pantone (sugestão) | Pantone Warm Gray 2 C |
### Surface Inverse `surface.inverse`
> v1.1 — warm black, era #080808
| Espaço | Valor |
| --- | --- |
| HEX | `#1C1917` |
| RGB | `28, 25, 23` |
| CMYK (aprox) | `C 0  M 11  Y 18  K 89` |
| LAB (CIE) | `L 9.02  a 1  b 1.94` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `24°, 10%, 10%` |
| Pantone (sugestão) | Pantone Black 6 C — neutro quente |
### Surface Inverse Alt `surface.inverseAlt`
> Reserva não utilizada
| Espaço | Valor |
| --- | --- |
| HEX | `#080A09` |
| RGB | `8, 10, 9` |
| CMYK (aprox) | `C 20  M 0  Y 10  K 96` |
| LAB (CIE) | `L 2.61  a -0.66  b 0.19` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `150°, 11%, 4%` |
| Pantone (sugestão) | Pantone Black C ou Black 6 C |
### Accent Default `accent.default`
> v1.1 NOVO — bronze maduro, ~60% saturação
| Espaço | Valor |
| --- | --- |
| HEX | `#A6783E` |
| RGB | `166, 120, 62` |
| CMYK (aprox) | `C 0  M 28  Y 63  K 35` |
| LAB (CIE) | `L 53.91  a 11.65  b 38.35` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `33°, 46%, 45%` |
| Pantone (sugestão) | Pantone 7568 C ou 873 C (acabamento metalizado) |
### Text On Light `text.onLight`
> v1.1 — warm black em vez de cool
| Espaço | Valor |
| --- | --- |
| HEX | `#1C1917` |
| RGB | `28, 25, 23` |
| CMYK (aprox) | `C 0  M 11  Y 18  K 89` |
| LAB (CIE) | `L 9.02  a 1  b 1.94` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `24°, 10%, 10%` |
| Pantone (sugestão) | Pantone Black 6 C — neutro quente |
### Text On Dark `text.onDark`
> v1.1 — cream em vez de white puro
| Espaço | Valor |
| --- | --- |
| HEX | `#F5F0EA` |
| RGB | `245, 240, 234` |
| CMYK (aprox) | `C 0  M 2  Y 4  K 4` |
| LAB (CIE) | `L 95.02  a 0.64  b 3.49` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `33°, 35%, 94%` |
| Pantone (sugestão) | Pantone 9143 C ou Warm Gray 1 C |
### Text On Canvas `text.onCanvas`
| Espaço | Valor |
| --- | --- |
| HEX | `#1C1917` |
| RGB | `28, 25, 23` |
| CMYK (aprox) | `C 0  M 11  Y 18  K 89` |
| LAB (CIE) | `L 9.02  a 1  b 1.94` (mais confiável que CMYK em prensa com espectrofotômetro) |
| HSL | `24°, 10%, 10%` |
| Pantone (sugestão) | Pantone Black 6 C — neutro quente |
## Checklist do operador
- [ ] Provar Accent Default em prova impressa (não confiar no monitor).
- [ ] Verificar registro entre tintas onde o accent default aparecer — pode marcar fora de eixo.
- [ ] Para fundos extensos escuros, usar rich black em vez de K100 puro.
- [ ] Cores warm sutis precisam de balance correto de amarelo — checar dot gain.
- [ ] Para grandes áreas chapadas, considerar varnish ou laminação fosca para preservar elegância.