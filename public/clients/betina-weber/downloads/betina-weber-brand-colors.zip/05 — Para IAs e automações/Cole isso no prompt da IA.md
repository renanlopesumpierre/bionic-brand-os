# Contexto cromático — Betina Weber

Bloco para colar em prompt de IA (Claude, GPT, Cursor, Figma AI). Compacto e literal.

```
Marca: Betina Weber
Slug: betina-weber
Versão da paleta: 1.1.0

Cores opacas (use estas para superfícies, texto, accent):
- surface.primary = #FFFFFF  (framer /Light)  
- surface.pure = #FFFFFF  (framer /White)  // Reservado a contextos light, não usar sobre Dark
- surface.cream = #F5F0EA  (framer /Cream)  // v1.1 NOVO — texto/detalhes sobre /Dark
- surface.canvas = #E5E4DE  (framer /Background)  // Bege pedra, cor-âncora do projeto
- surface.inverse = #1C1917  (framer /Dark)  // v1.1 — warm black, era #080808
- surface.inverseAlt = #080A09  (framer /Background Dark)  // Reserva não utilizada
- accent.default = #A6783E  (framer /Accent)  // v1.1 NOVO — bronze maduro, ~60% saturação
- text.onLight = #1C1917    // v1.1 — warm black em vez de cool
- text.onDark = #F5F0EA    // v1.1 — cream em vez de white puro
- text.onCanvas = #1C1917    

Cores com alpha (overlays, borders, estados):
- accent.subtle = rgba(166, 120, 62, 0.6)  (framer /Accent Subtle)  // Hover states e transições
- accent.faint = rgba(166, 120, 62, 0.1)  (framer /Accent Faint)  // Highlights de fundo editorial raríssimos
- border.onLight = rgba(22, 35, 27, 0.16)  (framer /Border Dark)  
- border.onDark = rgba(245, 240, 234, 0.1)  (framer /Border Light)  // v1.1 — usa cream em vez de white puro
- overlay.onDark = rgba(245, 240, 234, 0.16)  (framer /Background Transparent)  // v1.1 — cream alpha em vez de white alpha
- overlay.dimDark = rgba(22, 35, 27, 0.6)  (framer /Transparent Dark)  
- overlay.dimLight = rgba(255, 252, 245, 0.5)  (framer /Transparent Light)  
- overlay.reset = rgba(40, 44, 41, 0)  (framer /Transparent)  
- text.muted = rgba(35, 31, 32, 0.5)  (framer /Muted)  
- feedback.error = rgba(255, 34, 68, 0.15)  (framer /Error)  

Regras invioláveis:
- Sem gradientes
- Sem sombras
- Accent nunca em background de botão primário
- Accent nunca em headings
- Accent máximo 2 usos por viewport
- Tipografia: Spectral (serif, headings) + TASA Orbiter (sans, body)
- Radius máximo 6px, exclusivo de botões
```

## Para uso com Tokens Studio (Figma)

Importe `palette.figma.tokens.json` direto no plugin Tokens Studio.

## Para uso programático

- Web: `palette.css` (CSS vars) ou `palette.scss`
- Tailwind: `palette.tailwind.js`
- Sistema: `palette.json` (fonte canônica)
