# Como aprovar uma peça — Betina Weber

Pra quem é dono da marca, aprova peças, ou contrata fornecedor. **Não precisa entender técnica** — só precisa saber o que cobrar e o que recusar.

## A paleta em uma frase

**Bege pedra** como cor-âncora, **warm black** e **cream** como pares pra texto, e um **bronze dessaturado** como única cor de acento. É isso. Fornecedor que entregar peça com cor fora dessas, recusar.

## Cores que devem aparecer

### Surface Primary — `#FFFFFF`
Nome interno (Framer): `/Light`
### Surface Pure — `#FFFFFF`
> Reservado a contextos light, não usar sobre Dark
Nome interno (Framer): `/White`
### Surface Cream — `#F5F0EA`
> v1.1 NOVO — texto/detalhes sobre /Dark
Nome interno (Framer): `/Cream`
### Surface Canvas — `#E5E4DE`
> Bege pedra, cor-âncora do projeto
Nome interno (Framer): `/Background`
### Surface Inverse — `#1C1917`
> v1.1 — warm black, era #080808
Nome interno (Framer): `/Dark`
### Surface Inverse Alt — `#080A09`
> Reserva não utilizada
Nome interno (Framer): `/Background Dark`
### Accent Default — `#A6783E`
> v1.1 NOVO — bronze maduro, ~60% saturação
Nome interno (Framer): `/Accent`
### Text On Light — `#1C1917`
> v1.1 — warm black em vez de cool
### Text On Dark — `#F5F0EA`
> v1.1 — cream em vez de white puro
### Text On Canvas — `#1C1917`

## Bandeiras vermelhas — recuse se vir

Antes de aprovar uma peça, passe os olhos por essa lista. Qualquer um destes itens é motivo pra pedir refazer:

- Cor que não está na lista acima
- Gradiente de qualquer tipo
- Bronze como fundo de botão (descaracteriza)
- Bronze em texto corrido (prejudica leitura)
- Mais de 2 usos do bronze por tela/peça
- Sombras (a marca não usa)
- Curvas decorativas além do raio de 6px (exclusivo de botões)

## Quer entender mais a fundo?

- **Por que essas cores e não outras** → leia `Histórico das decisões cromáticas.md` (mesma pasta).
- **Por que o bronze tem regras tão estritas** → leia `Regras do bronze (accent).md` (mesma pasta).
- **Visão geral pra mostrar a alguém** → abra `Catálogo visual da paleta.png` (mesma pasta).
