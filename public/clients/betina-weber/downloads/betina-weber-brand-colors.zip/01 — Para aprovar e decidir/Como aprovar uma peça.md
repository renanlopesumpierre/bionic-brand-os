# Como aprovar uma peça — Betina Weber
Pra quem é dono da marca, aprova peças, ou contrata fornecedor. **Não precisa entender técnica** — só precisa saber o que cobrar e o que recusar.
## A paleta em uma frase
Superfícies: **Surface Primary** `#FFFFFF`, **Surface Pure** `#FFFFFF`, **Surface Cream** `#F5F0EA`, **Surface Canvas** `#E5E4DE`. Acento: **Accent Default** `#A6783E`. Qualquer cor fora dessas em peça oficial: recusar.
## Cores que devem aparecer
### Surface Primary — `#FFFFFF`
Nome interno (Framer): `/Light`
### Surface Pure — `#FFFFFF`
> Reservado a contextos light, não usar sobre Dark
Nome interno (Framer): `/White`
### Surface Cream — `#F5F0EA`
> v1.1 NOVO — texto/detalhes sobre /Dark
Nome interno (Framer): `/Cream`
### Surface Canvas — `#E5E4DE`
> Bege pedra, cor-âncora do projeto
Nome interno (Framer): `/Background`
### Surface Inverse — `#1C1917`
> v1.1 — warm black, era #080808
Nome interno (Framer): `/Dark`
### Surface Inverse Alt — `#080A09`
> Reserva não utilizada
Nome interno (Framer): `/Background Dark`
### Accent Default — `#A6783E`
> v1.1 NOVO — bronze maduro, ~60% saturação
Nome interno (Framer): `/Accent`
### Legacy Web Amarelo Cta — `#CA8A04`
> Acento original do rascunho pessoal. Usado em CTAs primários e destaques editoriais ("Method" no hero).
### Legacy Web Amarelo Highlight — `#F0C040`
> Variante mais clara, função decorativa pontual em hovers e ornamentos.
### Legacy Web Warm Grey — `#A8998C`
> Cinza pedra warm derivado do canvas. Usado como texto suave e divisores em fundo cream.
### Legacy Web Cream Over Dark — `#F5F0EA`
> Texto e detalhes sobre Dark — substitui white puro.
### Text On Light — `#1C1917`
> v1.1 — warm black em vez de cool
### Text On Dark — `#F5F0EA`
> v1.1 — cream em vez de white puro
### Text On Canvas — `#1C1917`
## Bandeiras vermelhas — recuse se vir
Antes de aprovar uma peça, passe os olhos por essa lista. Qualquer um destes itens é motivo pra pedir refazer:
- Cor que não está na lista acima
- Gradiente de qualquer tipo
- Accent Default como fundo de botão primário (descaracteriza a hierarquia)
- Accent Default em texto corrido (prejudica leitura)
- Mais de 2 usos do accent default por tela/peça
- Sombras (a marca não usa)
- Curvas decorativas além do raio padrão de botões
## Quer entender mais a fundo?
- **Por que essas cores e não outras** → leia `Histórico das decisões cromáticas.md` (mesma pasta).
- **Por que o accent tem regras tão estritas** → leia `Regras do accent.md` (mesma pasta).
- **Visão geral pra mostrar a alguém** → abra `Catálogo visual da paleta.png` (mesma pasta).