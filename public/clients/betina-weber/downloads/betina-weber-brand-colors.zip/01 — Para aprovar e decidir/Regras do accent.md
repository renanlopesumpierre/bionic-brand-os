# Betina Weber — Regras do Accent (#A6783E)

O accent é a única cor não-monocromática do sistema. É **assinatura editorial**, não cor funcional. Existe para pontuar momentos no scroll — não para construir hierarquia ou chamar atenção genérica.

## Onde **PODE** ser usado

- ✅ Divisor editorial 2px × 40px antes de heading de seção importante (máx 1/seção, 2/página)
- ✅ Numeral de destaque em metrics cards (1 dos 3, não todos)
- ✅ Label caps pequeno sob logotipo (ex: 'The Growth Method')
- ✅ Underline de hover em links textuais
- ✅ Icon discreto até 20px sempre acompanhando texto
- ✅ Email/link de contato textual no footer (único link destacado)
- ✅ Hover state de social icons
- ✅ Aspas de abertura em testimonials (detalhe editorial)

## Onde **NUNCA** deve ser usado

- ❌ Background de botão primário (contradiz autoridade calma)
- ❌ Headings de qualquer tamanho (preservam monocromático)
- ❌ Body de texto (prejudica legibilidade)
- ❌ Background de card grande (quebra ritmo cromático)
- ❌ Gradientes de qualquer tipo (zero gradientes no sistema)
- ❌ Elementos decorativos sem função informacional
- ❌ Qualquer coisa que compita com hierarquia tipográfica como atenção

## Regras estruturais

- **Máximo por viewport:** 2 aparições.
- **Teste de remoção:** Se remover todo /Accent, peça ainda precisa funcionar perfeitamente. Se precisa do accent pra comunicar, design falhou antes.
- **Accent sobre accent:** Nunca accent sobre accent; sempre separado por superfície monocromática
- **Em dúvida:** Em contexto ambíguo, não usar. Accent ausente é melhor que accent mal aplicado.

---

Lembrete: o accent foi calibrado a partir de #CA8A04 (96% saturação) **dessaturado para ~60%** justamente para preservar autoridade calma. Saturar de novo destrói a decisão.
