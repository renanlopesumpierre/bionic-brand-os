# Betina Weber — Histórico de decisões cromáticas

## Caminho adotado: Hybrid calibrated

Paleta warm + accent bronze dessaturado usado só como assinatura editorial

**Resultado:** Preserva autoridade calma, ganha reconhecimento cromático, respeita intenção original refinando execução

## Caminhos rejeitados

### Saturated accent #CA8A04 (Betina's raw draft)

96% saturação escorrega pra mostarda em monitores diferentes; CTA sólido em âmbar saturado contradiz vetor verbal 'autoridade calma'

### Monochromatic rigor (v1.0 original)

Ausência total de acento deixa marca genérica dentro da categoria advisory premium; monocromático puro é padrão de estúdio de design, não de board advisor

## Changelog

### v1.1

- Dark migrou de #080808 (cool) para #1C1917 (warm black)
- Cream (#F5F0EA) introduzido como texto-on-dark padrão, substituindo white puro
- Accent (#A6783E) introduzido — bronze maduro, primeira cor de acento do sistema
- Accent calibrado a partir do âmbar #CA8A04 (96% sat) do rascunho pessoal da Betina, dessaturado pra ~60% para preservar autoridade calma
- Protocolo estrito de uso do Accent definido (seção component.accent.rules)
- Border-on-dark migrou de rgba(255,255,255,0.1) para rgba(245,240,234,0.1) usando cream

---

Por que documentar isto: as decisões cromáticas que **não** foram tomadas são tão importantes quanto as que foram. Quando alguém propuser "e se a gente colorir o CTA de bronze?", a resposta já está aqui.
