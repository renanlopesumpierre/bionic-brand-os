# Betina Weber — Cores

Versão 1.1.0 · 24 cores no total (14 sólidas + 10 com transparência).

Este pacote tem **uma pasta pra cada papel** — abra a sua e ignore o resto.

---

## Onde abrir, dependendo de quem você é

### Sou o(a) **dono(a) da marca** — quero aprovar peças
→ Abra **`01 — Para aprovar e decidir/`**
Comece pelo `Catálogo visual da paleta.png`. Depois leia `Como aprovar uma peça.md` e `Regras do accent.md`.

### Sou **designer** (Figma, Adobe, Inkscape, etc.)
→ Abra **`02 — Para design/`**
Tem uma subpasta por ferramenta, com o arquivo nativo + um `Como importar` curtinho. Use a sua e ignore o resto.

### Vou enviar pra **gráfica** ou trabalho com **impressão**
→ Abra **`03 — Para impressão (gráfica)/`**
Comece por `LEIA PRIMEIRO — Para a gráfica.md`. A folha A4 já está pronta pra imprimir.

### Sou **programador(a)** — vou usar no código
→ Abra **`04 — Para desenvolvimento (programação)/`**
Subpastas por plataforma (Web, iOS, Android, Scripts). Cada uma tem `Como usar.md`. Auditoria WCAG de contraste também está aqui.

### Sou uma **IA**, ou estou montando uma automação
→ Abra **`05 — Para IAs e automações/`**
Bloco compacto pra colar em prompt + JSON canônico com todos os formatos.

---

## Por que tem tanta pasta?

Porque um arquivo de cor que serve pro Figma **não serve** pro Adobe, e o que serve pro Adobe **não serve** pra gráfica. Em vez de te entregar um zip com 30 arquivos misturados, separei por papel. Você só precisa da sua pasta.

Se for só baixar pra arquivar — o `Catálogo visual da paleta.png` em `01 — Para aprovar e decidir/` é a foto-resumo de tudo.

---

## Estrutura do pacote

```
Betina Weber — Cores/
│
├── LEIA-ME-PRIMEIRO.md                    ← você está aqui
│
├── 01 — Para aprovar e decidir/
│   ├── Catálogo visual da paleta.png
│   ├── Catálogo visual da paleta.svg
│   ├── Como aprovar uma peça.md
│   ├── Regras do accent.md
│   └── Histórico das decisões cromáticas.md
│
├── 02 — Para design/
│   ├── Adobe (Illustrator, Photoshop, InDesign)/
│   │   ├── Betina Weber.ase
│   │   └── Como importar no Adobe.md
│   ├── Figma/
│   │   ├── betina-weber.tokens.json
│   │   └── Como importar no Figma.md
│   ├── GIMP, Inkscape, Krita/
│   │   ├── Betina Weber.gpl
│   │   └── Como importar.md
│   └── Swatches individuais/
│       ├── 01 — Surface Primary.svg
│       └── ... (um SVG por cor, drag & drop)
│
├── 03 — Para impressão (gráfica)/
│   ├── LEIA PRIMEIRO — Para a gráfica.md
│   ├── Folha de cores A4 (pronta pra imprimir).png
│   ├── Folha de cores A4 (pronta pra imprimir).svg
│   └── Cores em CMYK, LAB e Pantone.json
│
├── 04 — Para desenvolvimento (programação)/
│   ├── Web/  (CSS, SCSS, LESS, Tailwind v4 e v3)
│   ├── iOS (Swift)/
│   ├── Android (Kotlin)/
│   ├── Scripts (JavaScript, TypeScript, Python)/
│   ├── Contraste WCAG (auditoria de acessibilidade).json
│   └── Contraste WCAG (relatório legível).md
│
└── 05 — Para IAs e automações/
    ├── Cole isso no prompt da IA.md
    └── paleta-canônica (todos os formatos).json
```

---

## Resumo do sistema

24 cores divididas em 7 grupos: Surface (6), Accent (3), Legacy Web (4), Border (2), Overlay (4), Text (4), Feedback (1).

**Cores canônicas sólidas:**

- `#FFFFFF` **Surface Primary** · framer `/Light`
- `#FFFFFF` **Surface Pure** · framer `/White` — Reservado a contextos light, não usar sobre Dark
- `#F5F0EA` **Surface Cream** · framer `/Cream` — v1.1 NOVO — texto/detalhes sobre /Dark
- `#E5E4DE` **Surface Canvas** · framer `/Background` — Bege pedra, cor-âncora do projeto
- `#1C1917` **Surface Inverse** · framer `/Dark` — v1.1 — warm black, era #080808
- `#080A09` **Surface Inverse Alt** · framer `/Background Dark` — Reserva não utilizada
- `#A6783E` **Accent Default** · framer `/Accent` — v1.1 NOVO — bronze maduro, ~60% saturação
- `#CA8A04` **Legacy Web Amarelo Cta** — Acento original do rascunho pessoal. Usado em CTAs primários e destaques editoriais ("Method" no hero).
- `#F0C040` **Legacy Web Amarelo Highlight** — Variante mais clara, função decorativa pontual em hovers e ornamentos.
- `#A8998C` **Legacy Web Warm Grey** — Cinza pedra warm derivado do canvas. Usado como texto suave e divisores em fundo cream.
- `#F5F0EA` **Legacy Web Cream Over Dark** — Texto e detalhes sobre Dark — substitui white puro.
- `#1C1917` **Text On Light** — v1.1 — warm black em vez de cool
- `#F5F0EA` **Text On Dark** — v1.1 — cream em vez de white puro
- `#1C1917` **Text On Canvas**

---

## Atualização

Este pacote é gerado automaticamente. Se você editar arquivos aqui dentro, suas mudanças somem na próxima geração. A fonte de verdade é o `design-tokens.json` da marca.

Gerado em 2026-04-26.
