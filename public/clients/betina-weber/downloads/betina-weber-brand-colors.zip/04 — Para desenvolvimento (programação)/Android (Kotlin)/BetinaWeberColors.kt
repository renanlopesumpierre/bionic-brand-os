// Betina Weber — Jetpack Compose — gerado automaticamente.

import androidx.compose.ui.graphics.Color

object BetinaWeberColors {
  val SurfacePrimary = Color(red = 1.0000f, green = 1.0000f, blue = 1.0000f, alpha = 1.0000f)
  /** Reservado a contextos light, não usar sobre Dark */
  val SurfacePure = Color(red = 1.0000f, green = 1.0000f, blue = 1.0000f, alpha = 1.0000f)
  /** v1.1 NOVO — texto/detalhes sobre /Dark */
  val SurfaceCream = Color(red = 0.9608f, green = 0.9412f, blue = 0.9176f, alpha = 1.0000f)
  /** Bege pedra, cor-âncora do projeto */
  val SurfaceCanvas = Color(red = 0.8980f, green = 0.8941f, blue = 0.8706f, alpha = 1.0000f)
  /** v1.1 — warm black, era #080808 */
  val SurfaceInverse = Color(red = 0.1098f, green = 0.0980f, blue = 0.0902f, alpha = 1.0000f)
  /** Reserva não utilizada */
  val SurfaceInverseAlt = Color(red = 0.0314f, green = 0.0392f, blue = 0.0353f, alpha = 1.0000f)
  /** v1.1 NOVO — bronze maduro, ~60% saturação */
  val AccentDefault = Color(red = 0.6510f, green = 0.4706f, blue = 0.2431f, alpha = 1.0000f)
  /** Hover states e transições */
  val AccentSubtle = Color(red = 0.6510f, green = 0.4706f, blue = 0.2431f, alpha = 0.6000f)
  /** Highlights de fundo editorial raríssimos */
  val AccentFaint = Color(red = 0.6510f, green = 0.4706f, blue = 0.2431f, alpha = 0.1000f)
  /** Acento original do rascunho pessoal. Usado em CTAs primários e destaques editoriais ("Method" no hero). */
  val LegacyWebAmareloCta = Color(red = 0.7922f, green = 0.5412f, blue = 0.0157f, alpha = 1.0000f)
  /** Variante mais clara, função decorativa pontual em hovers e ornamentos. */
  val LegacyWebAmareloHighlight = Color(red = 0.9412f, green = 0.7529f, blue = 0.2510f, alpha = 1.0000f)
  /** Cinza pedra warm derivado do canvas. Usado como texto suave e divisores em fundo cream. */
  val LegacyWebWarmGrey = Color(red = 0.6588f, green = 0.6000f, blue = 0.5490f, alpha = 1.0000f)
  /** Texto e detalhes sobre Dark — substitui white puro. */
  val LegacyWebCreamOverDark = Color(red = 0.9608f, green = 0.9412f, blue = 0.9176f, alpha = 1.0000f)
  val BorderOnLight = Color(red = 0.0863f, green = 0.1373f, blue = 0.1059f, alpha = 0.1600f)
  /** v1.1 — usa cream em vez de white puro */
  val BorderOnDark = Color(red = 0.9608f, green = 0.9412f, blue = 0.9176f, alpha = 0.1000f)
  /** v1.1 — cream alpha em vez de white alpha */
  val OverlayOnDark = Color(red = 0.9608f, green = 0.9412f, blue = 0.9176f, alpha = 0.1600f)
  val OverlayDimDark = Color(red = 0.0863f, green = 0.1373f, blue = 0.1059f, alpha = 0.6000f)
  val OverlayDimLight = Color(red = 1.0000f, green = 0.9882f, blue = 0.9608f, alpha = 0.5000f)
  val OverlayReset = Color(red = 0.1569f, green = 0.1725f, blue = 0.1608f, alpha = 0.0000f)
  /** v1.1 — warm black em vez de cool */
  val TextOnLight = Color(red = 0.1098f, green = 0.0980f, blue = 0.0902f, alpha = 1.0000f)
  /** v1.1 — cream em vez de white puro */
  val TextOnDark = Color(red = 0.9608f, green = 0.9412f, blue = 0.9176f, alpha = 1.0000f)
  val TextOnCanvas = Color(red = 0.1098f, green = 0.0980f, blue = 0.0902f, alpha = 1.0000f)
  val TextMuted = Color(red = 0.1373f, green = 0.1216f, blue = 0.1255f, alpha = 0.5000f)
  val FeedbackError = Color(red = 1.0000f, green = 0.1333f, blue = 0.2667f, alpha = 0.1500f)
}
