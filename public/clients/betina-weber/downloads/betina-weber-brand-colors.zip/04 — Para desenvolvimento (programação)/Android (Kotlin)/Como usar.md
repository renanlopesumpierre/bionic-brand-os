# Como usar as cores no Android

Dois arquivos, dois mundos: XML (Views clássicas) e Kotlin (Jetpack Compose). Use o que combina com seu projeto.

## Android Views (XML)

1. Copie o conteúdo de `colors.xml` pro seu `app/src/main/res/values/colors.xml`
   (ou substitua o arquivo se ainda não tiver cores customizadas).
2. Use no XML de layout:
   ```xml
   <View
     android:background="@color/color_surface_inverse"
     android:textColor="@color/color_text_on_dark" />
   ```
3. Em Kotlin: `ContextCompat.getColor(context, R.color.color_surface_inverse)`

## Jetpack Compose

1. Adicione `BetinaWeberColors.kt` em `app/src/main/java/.../ui/theme/`.
2. Use direto:
   ```kotlin
   import com.suaempresa.ui.theme.BetinaWeberColors

   Surface(
     color = BetinaWeberColors.SurfaceInverse,
   ) {
     Text("Olá", color = BetinaWeberColors.TextOnDark)
   }
   ```

## Recomendação extra

Pra suporte completo a Material 3 + Dark Theme automático, considere mapear as cores deste arquivo dentro do seu `MaterialTheme` customizado. Esta exposição é o atalho — mapear via theme é o caminho idiomático.
