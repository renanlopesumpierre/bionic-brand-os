// Betina Weber — Swift / SwiftUI / UIKit — gerado automaticamente.

import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

enum BetinaWeberColors {
  static let surfacePrimary = Color(red: 1.0000, green: 1.0000, blue: 1.0000, opacity: 1)
  /// Reservado a contextos light, não usar sobre Dark
  static let surfacePure = Color(red: 1.0000, green: 1.0000, blue: 1.0000, opacity: 1)
  /// v1.1 NOVO — texto/detalhes sobre /Dark
  static let surfaceCream = Color(red: 0.9608, green: 0.9412, blue: 0.9176, opacity: 1)
  /// Bege pedra, cor-âncora do projeto
  static let surfaceCanvas = Color(red: 0.8980, green: 0.8941, blue: 0.8706, opacity: 1)
  /// v1.1 — warm black, era #080808
  static let surfaceInverse = Color(red: 0.1098, green: 0.0980, blue: 0.0902, opacity: 1)
  /// Reserva não utilizada
  static let surfaceInverseAlt = Color(red: 0.0314, green: 0.0392, blue: 0.0353, opacity: 1)
  /// v1.1 NOVO — bronze maduro, ~60% saturação
  static let accentDefault = Color(red: 0.6510, green: 0.4706, blue: 0.2431, opacity: 1)
  /// Hover states e transições
  static let accentSubtle = Color(red: 0.6510, green: 0.4706, blue: 0.2431, opacity: 0.6)
  /// Highlights de fundo editorial raríssimos
  static let accentFaint = Color(red: 0.6510, green: 0.4706, blue: 0.2431, opacity: 0.1)
  /// Acento original do rascunho pessoal. Usado em CTAs primários e destaques editoriais ("Method" no hero).
  static let legacyWebAmareloCta = Color(red: 0.7922, green: 0.5412, blue: 0.0157, opacity: 1)
  /// Variante mais clara, função decorativa pontual em hovers e ornamentos.
  static let legacyWebAmareloHighlight = Color(red: 0.9412, green: 0.7529, blue: 0.2510, opacity: 1)
  /// Cinza pedra warm derivado do canvas. Usado como texto suave e divisores em fundo cream.
  static let legacyWebWarmGrey = Color(red: 0.6588, green: 0.6000, blue: 0.5490, opacity: 1)
  /// Texto e detalhes sobre Dark — substitui white puro.
  static let legacyWebCreamOverDark = Color(red: 0.9608, green: 0.9412, blue: 0.9176, opacity: 1)
  static let borderOnLight = Color(red: 0.0863, green: 0.1373, blue: 0.1059, opacity: 0.16)
  /// v1.1 — usa cream em vez de white puro
  static let borderOnDark = Color(red: 0.9608, green: 0.9412, blue: 0.9176, opacity: 0.1)
  /// v1.1 — cream alpha em vez de white alpha
  static let overlayOnDark = Color(red: 0.9608, green: 0.9412, blue: 0.9176, opacity: 0.16)
  static let overlayDimDark = Color(red: 0.0863, green: 0.1373, blue: 0.1059, opacity: 0.6)
  static let overlayDimLight = Color(red: 1.0000, green: 0.9882, blue: 0.9608, opacity: 0.5)
  static let overlayReset = Color(red: 0.1569, green: 0.1725, blue: 0.1608, opacity: 0)
  /// v1.1 — warm black em vez de cool
  static let textOnLight = Color(red: 0.1098, green: 0.0980, blue: 0.0902, opacity: 1)
  /// v1.1 — cream em vez de white puro
  static let textOnDark = Color(red: 0.9608, green: 0.9412, blue: 0.9176, opacity: 1)
  static let textOnCanvas = Color(red: 0.1098, green: 0.0980, blue: 0.0902, opacity: 1)
  static let textMuted = Color(red: 0.1373, green: 0.1216, blue: 0.1255, opacity: 0.5)
  static let feedbackError = Color(red: 1.0000, green: 0.1333, blue: 0.2667, opacity: 0.15)
}

#if canImport(UIKit)
extension BetinaWeberColors {
  static let surfacePrimaryUI = UIColor(red: 1.0000, green: 1.0000, blue: 1.0000, alpha: 1)
  static let surfacePureUI = UIColor(red: 1.0000, green: 1.0000, blue: 1.0000, alpha: 1)
  static let surfaceCreamUI = UIColor(red: 0.9608, green: 0.9412, blue: 0.9176, alpha: 1)
  static let surfaceCanvasUI = UIColor(red: 0.8980, green: 0.8941, blue: 0.8706, alpha: 1)
  static let surfaceInverseUI = UIColor(red: 0.1098, green: 0.0980, blue: 0.0902, alpha: 1)
  static let surfaceInverseAltUI = UIColor(red: 0.0314, green: 0.0392, blue: 0.0353, alpha: 1)
  static let accentDefaultUI = UIColor(red: 0.6510, green: 0.4706, blue: 0.2431, alpha: 1)
  static let accentSubtleUI = UIColor(red: 0.6510, green: 0.4706, blue: 0.2431, alpha: 0.6)
  static let accentFaintUI = UIColor(red: 0.6510, green: 0.4706, blue: 0.2431, alpha: 0.1)
  static let legacyWebAmareloCtaUI = UIColor(red: 0.7922, green: 0.5412, blue: 0.0157, alpha: 1)
  static let legacyWebAmareloHighlightUI = UIColor(red: 0.9412, green: 0.7529, blue: 0.2510, alpha: 1)
  static let legacyWebWarmGreyUI = UIColor(red: 0.6588, green: 0.6000, blue: 0.5490, alpha: 1)
  static let legacyWebCreamOverDarkUI = UIColor(red: 0.9608, green: 0.9412, blue: 0.9176, alpha: 1)
  static let borderOnLightUI = UIColor(red: 0.0863, green: 0.1373, blue: 0.1059, alpha: 0.16)
  static let borderOnDarkUI = UIColor(red: 0.9608, green: 0.9412, blue: 0.9176, alpha: 0.1)
  static let overlayOnDarkUI = UIColor(red: 0.9608, green: 0.9412, blue: 0.9176, alpha: 0.16)
  static let overlayDimDarkUI = UIColor(red: 0.0863, green: 0.1373, blue: 0.1059, alpha: 0.6)
  static let overlayDimLightUI = UIColor(red: 1.0000, green: 0.9882, blue: 0.9608, alpha: 0.5)
  static let overlayResetUI = UIColor(red: 0.1569, green: 0.1725, blue: 0.1608, alpha: 0)
  static let textOnLightUI = UIColor(red: 0.1098, green: 0.0980, blue: 0.0902, alpha: 1)
  static let textOnDarkUI = UIColor(red: 0.9608, green: 0.9412, blue: 0.9176, alpha: 1)
  static let textOnCanvasUI = UIColor(red: 0.1098, green: 0.0980, blue: 0.0902, alpha: 1)
  static let textMutedUI = UIColor(red: 0.1373, green: 0.1216, blue: 0.1255, alpha: 0.5)
  static let feedbackErrorUI = UIColor(red: 1.0000, green: 0.1333, blue: 0.2667, alpha: 0.15)
}
#endif
