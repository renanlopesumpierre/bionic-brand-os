# Como usar as cores no iOS (Swift / SwiftUI / UIKit)

O arquivo `BetinaWeberColors.swift` define um `enum` com **Color** (SwiftUI) e **UIColor** (UIKit) — escolha o que combina com seu projeto.

## Setup

1. Arraste `BetinaWeberColors.swift` pro seu projeto Xcode (target principal).
2. Pronto — `BetinaWeberColors` está disponível em qualquer arquivo Swift.

## Uso em SwiftUI

```swift
import SwiftUI

struct ContentView: View {
  var body: some View {
    Text("Olá")
      .foregroundColor(BetinaWeberColors.textOnDark)
      .background(BetinaWeberColors.surfaceInverse)
  }
}
```

## Uso em UIKit

```swift
import UIKit

let label = UILabel()
label.textColor = BetinaWeberColors.textOnDarkUI
label.backgroundColor = BetinaWeberColors.surfaceInverseUI
```

Note o sufixo `UI` nas versões UIKit.

## Recomendação extra

Pra Dynamic Color (light/dark mode automático), considere criar **Color Sets** no `.xcassets` usando os HEX deste arquivo. Esta exposição direta é o caminho mais rápido — Color Sets são o caminho mais idiomático.
