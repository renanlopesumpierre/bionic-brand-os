# Acessibilidade — Betina Weber

Matriz de contraste WCAG 2.2 entre todas as cores opacas de texto/accent sobre superfícies da paleta.

## Pares aprovados

- **Text On Dark** sobre **Surface Inverse Alt** — 17.52:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Light** sobre **Surface Primary** — 17.49:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Canvas** sobre **Surface Primary** — 17.49:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Light** sobre **Surface Pure** — 17.49:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Canvas** sobre **Surface Pure** — 17.49:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Light** sobre **Surface Cream** — 15.44:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Canvas** sobre **Surface Cream** — 15.44:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Dark** sobre **Surface Inverse** — 15.44:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Light** sobre **Surface Canvas** — 13.73:1 → AAA (texto normal) · AAA (texto grande)
- **Text On Canvas** sobre **Surface Canvas** — 13.73:1 → AAA (texto normal) · AAA (texto grande)
- **Accent Default** sobre **Surface Inverse Alt** — 5.08:1 → AA (texto normal) · AAA (texto grande)
- **Accent Default** sobre **Surface Inverse** — 4.48:1 → AA Large (texto normal) · AA (texto grande)
- **Accent Default** sobre **Surface Primary** — 3.91:1 → AA Large (texto normal) · AA (texto grande)
- **Accent Default** sobre **Surface Pure** — 3.91:1 → AA Large (texto normal) · AA (texto grande)
- **Accent Default** sobre **Surface Cream** — 3.45:1 → AA Large (texto normal) · AA (texto grande)
- **Accent Default** sobre **Surface Canvas** — 3.07:1 → AA Large (texto normal) · AA (texto grande)

## Pares reprovados (não usar pra texto)

- **Text On Light** sobre **Surface Inverse Alt** — 1.14:1 → FAIL (texto normal) · FAIL (texto grande)
- **Text On Canvas** sobre **Surface Inverse Alt** — 1.14:1 → FAIL (texto normal) · FAIL (texto grande)
- **Text On Dark** sobre **Surface Primary** — 1.13:1 → FAIL (texto normal) · FAIL (texto grande)
- **Text On Dark** sobre **Surface Pure** — 1.13:1 → FAIL (texto normal) · FAIL (texto grande)
- **Text On Dark** sobre **Surface Canvas** — 1.12:1 → FAIL (texto normal) · FAIL (texto grande)
- **Text On Dark** sobre **Surface Cream** — 1:1 → FAIL (texto normal) · FAIL (texto grande)
- **Text On Light** sobre **Surface Inverse** — 1:1 → FAIL (texto normal) · FAIL (texto grande)
- **Text On Canvas** sobre **Surface Inverse** — 1:1 → FAIL (texto normal) · FAIL (texto grande)

## Critérios

- **AAA**: ratio ≥ 7 (texto normal) / ≥ 4.5 (texto grande)
- **AA**: ratio ≥ 4.5 / ≥ 3
- **AA Large**: ratio ≥ 3 (apenas texto grande, ≥18pt regular ou ≥14pt bold)
- **FAIL**: abaixo de 3

Alpha colors não foram testados — calcule contra o fundo final composto.
