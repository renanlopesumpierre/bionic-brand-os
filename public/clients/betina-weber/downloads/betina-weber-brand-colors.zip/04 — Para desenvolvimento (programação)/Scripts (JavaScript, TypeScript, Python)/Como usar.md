# Como usar as cores em scripts (JavaScript, TypeScript, Python)

Três módulos com a mesma API: dicionário de cores indexado por nome.

## TypeScript

```ts
import { brandColors } from "./colors";

const accent = brandColors.accentDefault.hex;       // "#A6783E"
const dark = brandColors.surfaceInverse.rgb;        // [28, 25, 23]
```

Tipos exportados: `BrandColor`, `BrandColorKey`.

## JavaScript (CommonJS ou ESM)

```js
const { brandColors } = require("./colors");
// ou: import { brandColors } from "./colors.js";

console.log(brandColors.accentDefault.hex);
```

## Python

```python
from colors import BRAND_COLORS

accent = BRAND_COLORS["accent_default"]["hex"]      # "#A6783E"
dark = BRAND_COLORS["surface_inverse"]["rgb"]       # (28, 25, 23)
```

## Casos de uso típicos

- Geração de imagens (Pillow, sharp, canvas) com cores oficiais
- Validadores de peças (CI que reprova SVG com cor fora da paleta)
- Pipelines de exportação multi-formato
- Bots Slack/Discord com identidade visual consistente
