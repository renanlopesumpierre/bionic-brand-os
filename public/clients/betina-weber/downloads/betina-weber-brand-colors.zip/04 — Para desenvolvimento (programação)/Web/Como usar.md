# Como usar as cores no front-end web

5 arquivos, 5 estilos diferentes. Use **um** que combina com seu projeto.

## Tailwind CSS v4 (recomendado se já usa Tailwind)

1. Copie `cores-tailwind-v4.css` pro seu projeto.
2. No seu CSS principal:
   ```css
   @import "tailwindcss";
   @import "./cores-tailwind-v4.css";
   ```
3. Use direto: `<div class="bg-surface-canvas text-text-on-canvas">`

## Tailwind CSS v3

1. Copie `cores-tailwind-v3.config.js` pro seu projeto.
2. No `tailwind.config.js`:
   ```js
   const brandColors = require('./cores-tailwind-v3.config.js');
   module.exports = {
     theme: { extend: brandColors.theme.extend },
   };
   ```

## CSS puro (sem framework)

1. Copie `cores.css` e importe no `<head>` do HTML ou no CSS principal.
2. Use as variáveis:
   ```css
   .botao-primario {
     background: var(--color-surface-inverse);
     color: var(--color-text-on-dark);
   }
   ```

## SCSS

1. `@import "./cores.scss";`
2. Use: `background: $color-accent-default;`

## LESS

1. `@import "./cores.less";`
2. Use: `background: @color-accent-default;`

## Antes de usar — leia

- O **bronze (accent)** tem regras estritas. Veja `01 — Para aprovar e decidir/Regras do bronze (accent).md`.
- A auditoria de contraste WCAG está no mesmo nível desta pasta — `Contraste WCAG (relatório legível).md`.
