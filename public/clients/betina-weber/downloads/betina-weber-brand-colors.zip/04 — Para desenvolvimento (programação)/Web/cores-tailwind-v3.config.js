// Betina Weber — Tailwind theme.colors block
// Merge into tailwind.config.js > theme.extend.colors
// Usage example: <div class="bg-surface-canvas text-text-on-canvas">

module.exports = {
  theme: {
    extend: {
      colors: {
        "surface": {
          "primary": "#FFFFFF",
          "pure": "#FFFFFF",
          "cream": "#F5F0EA",
          "canvas": "#E5E4DE",
          "inverse": "#1C1917",
          "inverseAlt": "#080A09"
        },
        "accent": {
          "default": "#A6783E",
          "subtle": "rgba(166, 120, 62, 0.6)",
          "faint": "rgba(166, 120, 62, 0.1)"
        },
        "legacyWeb": {
          "amareloCta": "#CA8A04",
          "amareloHighlight": "#F0C040",
          "warmGrey": "#A8998C",
          "creamOverDark": "#F5F0EA"
        },
        "border": {
          "onLight": "rgba(22, 35, 27, 0.16)",
          "onDark": "rgba(245, 240, 234, 0.1)"
        },
        "overlay": {
          "onDark": "rgba(245, 240, 234, 0.16)",
          "dimDark": "rgba(22, 35, 27, 0.6)",
          "dimLight": "rgba(255, 252, 245, 0.5)",
          "reset": "rgba(40, 44, 41, 0)"
        },
        "text": {
          "onLight": "#1C1917",
          "onDark": "#F5F0EA",
          "onCanvas": "#1C1917",
          "muted": "rgba(35, 31, 32, 0.5)"
        },
        "feedback": {
          "error": "rgba(255, 34, 68, 0.15)"
        }
      },
    },
  },
};
