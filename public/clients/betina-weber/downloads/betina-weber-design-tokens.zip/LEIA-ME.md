# Design Tokens — Betina Weber

Versão 1.1.0 · gerado pelo Bionic Brand OS em 26/04/2026.

Este pacote contém o **sistema de design** de Betina Weber como tokens estruturados (JSON) e narrativa (Markdown).

---

## O que tem aqui

```
betina-weber-design-tokens/
├── betina-weber-design-tokens.json   ← tokens canônicos estruturados
├── betina-weber-design-system.md     ← sistema de design narrativo
├── LEIA-ME.pdf                   ← este documento
└── LEIA-ME.md                    ← mesmo conteúdo em markdown
```

---

## O que são design tokens

Tokens de design são **decisões cromáticas, tipográficas e espaciais codificadas como dados**. Em vez de "use o azul daquele PDF da branding", você tem `color.surface.primary = "#FFFFFF"` — uma fonte de verdade que vira CSS, Figma styles, Swift, Android XML, e qualquer outro formato programático.

Este JSON segue uma estrutura próxima ao **W3C Design Tokens Format Module** (ainda em fase comunitária, mas adotado por Tokens Studio, Style Dictionary e outras ferramentas).

---

## Estrutura do JSON (resumo)

| Seção | O que contém |
|---|---|
| `color.surface` | Superfícies (light, dark, canvas, cream) |
| `color.accent` | Cor(es) de acento e suas variantes |
| `color.text` | Cores de texto por contexto (sobre claro, sobre escuro) |
| `color.border`, `color.overlay`, `color.feedback` | Variações funcionais |
| `color.legacyWeb` (opcional) | Cores legadas em uso na web atual |
| `font.family` | Stacks CSS de serif e sans |
| `font.weight` | Pesos canônicos |
| `typography` | Escala completa (heading1-6, display, body, label) com font/size/lineHeight/letterSpacing/sample |
| `spacing` | Escala de espaçamento (0, 0-5, 1, 2, 2-5, ...) |
| `radius`, `border`, `shadow`, `breakpoint` | Outros tokens |
| `component` | Specs de componentes (button, card, etc.) |
| `visual`, `visualRules` | Regras de aplicação visual |

---

## Quando usar cada arquivo

### `betina-weber-design-tokens.json` — pra implementação

- Importar no Figma via plugin **Tokens Studio**
- Consumir em código (web, iOS, Android, scripts) — ver pacote dedicado **betina-weber-brand-colors.zip** que tem 16 formatos prontos (CSS, SCSS, LESS, Tailwind v3/v4, Figma, Android XML, iOS Swift, Compose Kotlin, TS/JS/Python, GIMP .gpl, Adobe .ase)
- Pipelines de validação visual (cor de peça vs paleta)
- Geração automática de variações (dark mode, theming multi-marca)

### `betina-weber-design-system.md` — pra entendimento

Versão narrativa explicando **por que** cada decisão foi tomada, regras de aplicação, exemplos de uso. Leitura recomendada antes de implementar.

---

## Acesso programático (API)

- **URL:** `/api/betina-weber/tokens`
- **Formato:** JSON (mesma fonte canônica)
- **Rate limit:** 60 req/min por IP

---

## Pacotes relacionados

- **`betina-weber-brand-colors.zip`** — paleta em 16 formatos visuais, organizada por audiência (designer, gráfica, dev, IA), com folha A4 imprimível e auditoria WCAG
- **`betina-weber-brand-fonts.zip`** — arquivos de fonte (TTF + WOFF2) e metadata
- **`betina-weber-brand-system.zip`** — sistema de marca completo (estratégia + visual + verbal + governança)

---

_Gerado pelo Bionic Brand OS._
