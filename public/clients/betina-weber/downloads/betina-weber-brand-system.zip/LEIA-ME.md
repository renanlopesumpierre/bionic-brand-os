# Brand System — Betina Weber

Versão 1.2.0 · gerado pelo Bionic Brand OS em 26/04/2026.

Este pacote contém o **sistema de marca estruturado** de Betina Weber em duas camadas: dados (JSON) pra máquinas e narrativa (Markdown) pra pessoas.

---

## O que tem aqui

```
betina-weber-brand-system/
├── betina-weber-brand-system.json   ← fonte canônica estruturada (máquinas)
├── betina-weber-brand-system.md     ← versão narrativa (pessoas)
├── LEIA-ME.pdf                  ← este documento
└── LEIA-ME.md                   ← mesmo conteúdo em markdown
```

---

## Quando usar cada um

### `betina-weber-brand-system.json` — pra máquinas

Schema estruturado com **20 seções**: essência, método, arquitetura de marca, audiência, sistema verbal, sistema visual, governança, gabaritos por peça, critérios de validação, frases sagradas, léxico canônico vs proibido, e mais.

**Quando importar:**

- Um agente conversacional (ex: Brand Agent do BBO) que precisa de contexto completo da marca
- Pipeline de validação automática (`peça → checa contra os 9 critérios`)
- Geração programática de copy seguindo gabaritos
- Auditorias automatizadas de coerência

### `betina-weber-brand-system.md` — pra pessoas

Mesmo conteúdo do JSON em formato narrativo, formatado pra leitura direta. **Quando ler:**

- Onboarding de novo colaborador na marca
- Reunião de alinhamento estratégico
- Quando precisa explicar a marca pra alguém de fora
- Como referência rápida sem abrir editor JSON

---

## Acesso programático (API)

Esta marca também responde no endpoint público:

- **URL:** `/api/betina-weber/brand-system`
- **Formato:** JSON (mesma fonte canônica deste ZIP)
- **Rate limit:** 60 req/min por IP
- **Quando usar:** integrações em tempo real (não precisa baixar e descompactar)

---

## Atualização

O Brand System é regenerado automaticamente sempre que a fonte canônica em `/Brandbook` é atualizada. Para forçar regeneração: `pnpm build:brand-system-zips`.

Não edite arquivos dentro deste ZIP — mudanças somem no próximo build. A fonte de verdade é o repositório do Brandbook da marca.

---

_Gerado pelo Bionic Brand OS — sistema operacional de marcas que conversam com humanos e máquinas._
