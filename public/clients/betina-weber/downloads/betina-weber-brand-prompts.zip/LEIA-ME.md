# Brand Prompts — Betina Weber

Gerado pelo Bionic Brand OS em 26/04/2026.

Pacote com **dois prompts prontos** pra usar com qualquer IA conversacional (Claude, GPT, Gemini, Cursor, Figma AI, etc.). Cada um tem um propósito diferente — escolha o certo pra economizar token e melhorar qualidade.

---

## O que tem aqui

```
betina-weber-brand-prompts/
├── betina-weber-brand-prompt.md          ← prompt destilado (leve, ~2-5KB)
├── betina-weber-brand-agent-master.md    ← system prompt operacional (~20-30KB)
├── LEIA-ME.pdf                       ← este documento
└── LEIA-ME.md                        ← mesmo conteúdo em markdown
```

---

## Qual usar quando

### `betina-weber-brand-prompt.md` — leve, pra contexto rápido

**Quando usar:**

- Você quer dar contexto de marca pra uma IA mas sem encher o prompt
- Tarefas pontuais: "escreva um post no tom dessa marca"
- IAs com janela de contexto limitada
- Custo de tokens importa (modelos pagos por input)

**Como usar:**

1. Abra o arquivo, copie o conteúdo inteiro
2. Cole **antes** da sua pergunta na IA
3. Faça a pergunta normalmente

Exemplo:

> [conteúdo do brand-prompt.md]
>
> Agora escreva 3 opções de headline pra um post no LinkedIn sobre liderança consciente.

### `betina-weber-brand-agent-master.md` — pesado, pra operação contínua

**Quando usar:**

- Você está montando um **agente persistente** (ChatGPT custom GPT, Claude Project, Cursor rules, etc.)
- Precisa que a IA execute **validação** rigorosa contra o sistema da marca (frases sagradas, léxico proibido, gabaritos)
- Trabalho de longo prazo onde a IA precisa "saber" tudo da marca

**Como usar:**

1. **ChatGPT Custom GPT:** cole no campo "Instructions"
2. **Claude Project:** cole em "Project knowledge" ou "Project instructions"
3. **Cursor:** cole em `.cursorrules` no root do projeto
4. **API direta:** use como `system` prompt em todas as chamadas

---

## Diferença prática

| Aspecto | brand-prompt.md | brand-agent-master.md |
|---|---|---|
| **Tamanho** | Pequeno (~2-5KB) | Grande (~20-30KB) |
| **Detalhe** | Resumo destilado | Sistema completo |
| **Uso** | Contexto pontual | System prompt operacional |
| **Custo de token** | Baixo | Alto (mas roda 1x na config) |
| **Cobertura** | Tom + posicionamento básico | Tom + léxico + gabaritos + validação + governança |

---

## Acesso programático (API)

Os mesmos prompts respondem em endpoints públicos do BBO:

- **`/api/betina-weber/prompt`** → markdown do brand-prompt destilado
- **`/api/betina-weber/prompt?flavor=master`** → markdown do brand-agent-master
- **Rate limit:** 60 req/min por IP

Pra um agente do BBO consumir em runtime, use a API. Pra configurar uma IA externa **uma vez**, use os arquivos deste ZIP.

---

## Atualização

Os prompts são gerados a partir do **Brand System** da marca (`brand-system.json`). Quando o sistema atualiza, os prompts atualizam automaticamente. Pra forçar regeneração: `pnpm build:brand-prompts-zips`.

---

_Gerado pelo Bionic Brand OS._
